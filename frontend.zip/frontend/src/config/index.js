// Exportar configuración desde un solo lugar
export { config } from './appConfig';
export { DEVICE_COLORS } from './colors';
