import { ThreeDot } from 'react-loading-indicators';

const LoadingSpinner = () => (
  <div className="flex items-center mx-auto justify-center p-8">
    <ThreeDot color="#FFFFFF" size="medium" text="" textColor="" />
  </div>
);

export default LoadingSpinner;
