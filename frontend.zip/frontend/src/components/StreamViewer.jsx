import { useState, useEffect, useRef } from 'react';
import { useWebRTC } from '../hooks/useWebRTC';

const StreamViewer = () => {
  const {
    devices,
    selectedDevices,
    streams,
    connectionStates,
    error,
    connectingDevices,
    globalConnectionState,
    connectToDevice,
    disconnectStream,
    toggleDevice,
    isDeviceActive,
    isDeviceConnecting,
    getDeviceConnectionState
  } = useWebRTC();

  const [layout, setLayout] = useState('grid'); // 'grid', 'list'
  const videoRefs = useRef({});
  const autoConnectedDevices = useRef(new Set());

  // Auto-conectar a nuevos dispositivos cuando aparecen
  useEffect(() => {
    devices.forEach(deviceId => {
      // Si el dispositivo no está activo, no se está conectando, y no se ha intentado conectar antes
      if (!selectedDevices.has(deviceId) && 
          !connectingDevices.has(deviceId) && 
          !autoConnectedDevices.current.has(deviceId)) {
        console.log('🔄 Auto-connecting to device:', deviceId);
        autoConnectedDevices.current.add(deviceId);
        toggleDevice(deviceId);
      }
    });

    // Limpiar dispositivos que ya no están disponibles
    autoConnectedDevices.current.forEach(deviceId => {
      if (!devices.includes(deviceId)) {
        console.log('🧹 Removing unavailable device from auto-connect:', deviceId);
        autoConnectedDevices.current.delete(deviceId);
      }
    });
  }, [devices, selectedDevices, connectingDevices, toggleDevice]);

  // Efecto para actualizar los videos cuando se reciben streams
  useEffect(() => {
    console.log('📺 Updating video elements with streams:', Object.keys(streams));
    
    Object.entries(streams).forEach(([deviceId, stream]) => {
      const videoElement = videoRefs.current[deviceId];
      
      if (videoElement && stream) {
        // Solo actualizar si el stream ha cambiado
        if (videoElement.srcObject !== stream) {
          console.log('🎥 Setting stream for video element:', deviceId);
          videoElement.srcObject = stream;
          
          // Intentar reproducir el video
          videoElement.play().catch(err => {
            console.error('❌ Error playing video for device:', deviceId, err);
          });
        }
      }
    });

    // Limpiar videos de dispositivos que ya no tienen stream
    Object.keys(videoRefs.current).forEach(deviceId => {
      const videoElement = videoRefs.current[deviceId];
      if (!streams[deviceId] && videoElement && videoElement.srcObject) {
        console.log('🧹 Cleaning up video for device:', deviceId);
        videoElement.srcObject.getTracks().forEach(track => track.stop());
        videoElement.srcObject = null;
      }
    });
  }, [streams]);

  // Limpiar streams cuando se desmonta el componente
  useEffect(() => {
    return () => {
      console.log('🧹 Cleaning up all video streams on unmount');
      Object.values(videoRefs.current).forEach(video => {
        if (video && video.srcObject) {
          video.srcObject.getTracks().forEach(track => track.stop());
          video.srcObject = null;
        }
      });
    };
  }, []);

  const getConnectionStateColor = (state) => {
    switch (state) {
      case 'connected':
        return 'bg-green-500';
      case 'connecting':
      case 'requesting':
        return 'bg-yellow-500 animate-pulse';
      case 'streaming':
        return 'bg-red-500 animate-pulse';
      case 'disconnected':
        return 'bg-gray-500';
      case 'failed':
      case 'closed':
        return 'bg-red-600';
      default:
        return 'bg-gray-400';
    }
  };

  const getConnectionStateText = (state) => {
    switch (state) {
      case 'connected':
        return 'Connected';
      case 'connecting':
      case 'requesting':
        return 'Connecting...';
      case 'streaming':
        return 'Live';
      case 'disconnected':
        return 'Disconnected';
      case 'failed':
        return 'Failed';
      case 'closed':
        return 'Closed';
      default:
        return 'Unknown';
    }
  };

  const getGridColumns = () => {
    const deviceCount = devices.length;
    if (deviceCount === 0) return 'grid-cols-1';
    if (deviceCount === 1) return 'grid-cols-1';
    if (deviceCount === 2) return 'grid-cols-1 md:grid-cols-2';
    if (deviceCount <= 4) return 'grid-cols-1 md:grid-cols-2';
    if (deviceCount <= 6) return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4';
  };

  return (
    <div className="w-full h-full min-h-[calc(100vh-12rem)] space-y-4 px-4 md:px-6">
      {/* Header Section */}
      <div className="glassmorphism-strong rounded-3xl p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">
              🎥 Live Video Streaming
            </h2>
            <p className="text-white/70">
              {devices.length === 0 
                ? 'Waiting for available devices...' 
                : `${devices.length} device${devices.length !== 1 ? 's' : ''} streaming live`}
            </p>
          </div>

          {/* Layout Toggle */}
          <div className="flex items-center gap-2 bg-white/10 rounded-xl p-1">
            <button
              onClick={() => setLayout('grid')}
              className={`px-4 py-2 rounded-lg transition-all ${
                layout === 'grid'
                  ? 'bg-cyan-600 text-white'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
              title="Grid View"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
            <button
              onClick={() => setLayout('list')}
              className={`px-4 py-2 rounded-lg transition-all ${
                layout === 'list'
                  ? 'bg-cyan-600 text-white'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
              title="List View"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </div>

        {/* Global Connection Status */}
        {globalConnectionState !== 'connected' && (
          <div className="mt-4 p-4 bg-yellow-500/20 border border-yellow-500/50 rounded-xl">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
              <p className="text-yellow-300">
                {globalConnectionState === 'connecting' 
                  ? 'Connecting to signaling server...' 
                  : 'Disconnected from signaling server. Reconnecting...'}
              </p>
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-xl">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <p className="text-red-300">{error}</p>
            </div>
          </div>
        )}
      </div>

      {/* Devices Grid/List */}
      {devices.length === 0 ? (
        <div className="glassmorphism-strong rounded-3xl p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <svg className="w-20 h-20 text-white/30 animate-pulse" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
              </svg>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-3 h-3 bg-cyan-500 rounded-full animate-ping"></div>
              </div>
            </div>
            <h3 className="text-xl text-white/70 font-semibold">Waiting for Broadcasting Devices</h3>
            <p className="text-white/50">No devices are currently streaming video</p>
            {globalConnectionState === 'connected' && (
              <p className="text-white/40 text-sm">Connected to signaling server. Waiting for devices to join...</p>
            )}
          </div>
        </div>
      ) : (
        <div className={`grid ${layout === 'grid' ? getGridColumns() : 'grid-cols-1'} gap-6`}>
          {devices.map((deviceId) => {
            const isActive = isDeviceActive(deviceId);
            const hasStream = streams[deviceId] != null;
            const isConnecting = isDeviceConnecting(deviceId);
            const connectionState = getDeviceConnectionState(deviceId);

            return (
              <div
                key={deviceId}
                className="glassmorphism-strong rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
              >
                {/* Device Header */}
                <div className="p-4 border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${
                      hasStream 
                        ? getConnectionStateColor('streaming')
                        : isConnecting
                        ? getConnectionStateColor('connecting')
                        : getConnectionStateColor('disconnected')
                    }`}></div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">{deviceId}</h3>
                      <p className="text-white/50 text-sm">
                        {hasStream 
                          ? getConnectionStateText('streaming')
                          : isConnecting
                          ? getConnectionStateText('connecting')
                          : getConnectionStateText(connectionState)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Video Container */}
                <div className="relative bg-black/50 aspect-video">
                  <video
                    ref={(el) => {
                      if (el) {
                        videoRefs.current[deviceId] = el;
                      }
                    }}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-contain"
                  />

                  {/* Placeholder when not streaming */}
                  {!hasStream && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-gray-900/50 to-black/50">
                      {isConnecting ? (
                        <div className="flex flex-col items-center gap-4">
                          <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                          <p className="text-white/70">Connecting...</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-4 p-8 text-center">
                          <svg className="w-16 h-16 text-white/30" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
                          </svg>
                          <p className="text-white/50">Waiting for stream...</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Live Indicator */}
                  {hasStream && (
                    <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 px-3 py-1.5 rounded-lg shadow-lg">
                      <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      <span className="text-white text-sm font-semibold">LIVE</span>
                    </div>
                  )}

                  {/* Connection State Indicator */}
                  {connectionState && (
                    <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded-lg shadow-lg">
                      <span className="text-white text-xs font-medium">
                        {connectionState.toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Device Info Footer */}
                <div className="p-4 border-t border-white/10">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-white/50">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                      </svg>
                      <span>
                        {hasStream 
                          ? 'Streaming'
                          : isConnecting
                          ? 'Connecting...'
                          : 'Not streaming'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-white/50">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                      </svg>
                      <span>WebRTC</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info Section */}
      <div className="glassmorphism-strong rounded-3xl p-6 shadow-lg">
        <div className="flex items-start gap-3">
          <svg className="w-6 h-6 text-cyan-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          <div className="flex-1">
            <h4 className="text-white font-semibold mb-2">How it works</h4>
            <ul className="text-white/70 text-sm space-y-1">
              <li>• Broadcasting devices are automatically displayed when they start streaming</li>
              <li>• Video streams are connected automatically - no need to click "View"</li>
              <li>• Video streaming uses WebRTC for low-latency peer-to-peer connections</li>
              <li>• <span className="text-cyan-400 font-semibold">Multiple devices stream simultaneously</span></li>
              <li>• The device list updates automatically when devices connect or disconnect</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Debug Info (Optional - Remove in production) */}
      {process.env.NODE_ENV === 'development' && (
        <div className="glassmorphism-strong rounded-3xl p-6 shadow-lg">
          <div className="flex items-start gap-3">
            <svg className="w-6 h-6 text-purple-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
            <div className="flex-1">
              <h4 className="text-white font-semibold mb-2">Debug Info</h4>
              <div className="text-white/70 text-xs space-y-1 font-mono">
                <div>Available Devices: {devices.length}</div>
                <div>Selected Devices: {selectedDevices.size}</div>
                <div>Active Streams: {Object.keys(streams).length}</div>
                <div>Connecting: {connectingDevices.size}</div>
                <div>Global State: {globalConnectionState}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StreamViewer;